The documentation is available on the wiki https://github.com/n1nj4sec/pupy/wiki
