#ifndef PYTHONINTERPRETER
#define PYTHONINTERPRETER
#include <stdint.h>
#include <stdbool.h>

uint32_t mainThread(int argc, char **argv, bool so);
#endif
