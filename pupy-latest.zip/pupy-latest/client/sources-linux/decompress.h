#ifndef DECOMPRESS_H
#define DECOMPRESS_H

int decompress(int fd, const char *buf, size_t size);

#endif /* DECOMPRESS_H */
